make all
make clean_o
./bin/main < 'Data/map.txt' > 'Data/path2.txt'
